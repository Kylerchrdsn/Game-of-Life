module Life
  VERSION = '0.0.2'
  LICENSE = 'MIT'
end
require_relative File.join('life', 'cell.rb')
require_relative File.join('life', 'field.rb')
